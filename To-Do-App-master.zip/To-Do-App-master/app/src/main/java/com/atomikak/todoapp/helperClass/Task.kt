package com.atomikak.todoapp.helperClass

data class Task(val t_id:Int?=null,val c_name:String,val t_title:String,val t_des:String,val t_time:String,val t_date:String,val t_status:String,val t_priority:String)
