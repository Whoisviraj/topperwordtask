package com.atomikak.todoapp.listeners

interface MyCheckBoxClick {

    fun OnCheckCliked(position:Int,type:String)

}