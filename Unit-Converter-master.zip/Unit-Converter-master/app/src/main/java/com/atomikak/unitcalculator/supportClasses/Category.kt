package com.atomikak.unitcalculator.supportClasses

data class Category(val image: Int, val name:String?=null,val units:ArrayList<String>?=null)